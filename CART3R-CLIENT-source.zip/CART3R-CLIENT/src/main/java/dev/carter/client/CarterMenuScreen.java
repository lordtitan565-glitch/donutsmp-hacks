package dev.carter.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class CarterMenuScreen extends Screen {
    public CarterMenuScreen() {
        super(Text.literal("CART3R CLIENT"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Toggle Sprint: available in settings"),
                button -> {}
        ).dimensions(centerX - 105, centerY - 10, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Close"),
                button -> this.close()
        ).dimensions(centerX - 50, centerY + 25, 100, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.fill(0, 0, this.width, this.height, 0xB8000000);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        context.fill(centerX - 125, centerY - 75, centerX + 125, centerY + 65, 0xFF160909);
        context.fill(centerX - 125, centerY - 75, centerX + 125, centerY - 73, 0xFFFF3030);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("CART3R CLIENT"), centerX, centerY - 55, 0xFFFF4040);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Client menu starter project"), centerX, centerY - 34, 0xFFFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
