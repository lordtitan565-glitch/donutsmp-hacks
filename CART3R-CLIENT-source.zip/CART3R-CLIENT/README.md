# CART3R CLIENT — Fabric starter

This is a clean starter project for a client-side Minecraft Fabric mod.

## Target
- Minecraft Java 1.21.11
- Fabric Loader 0.20.1
- Fabric API 0.141.6+1.21.11
- Java 25
- Loom 1.14.10

## Build in VS Code / PowerShell

1. Install JDK 25 and make sure `java -version` reports Java 25.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. If this project has a Gradle wrapper, run:

   `./gradlew.bat build`

   If the wrapper is not present, use an installed Gradle 8.14+ installation:

   `gradle build`

5. The mod JAR will be in `build/libs/`.

## Important
This ZIP contains source code and Gradle configuration, not a precompiled JAR.
The first build needs an internet connection to download Minecraft/Fabric dependencies.
The menu opens with Right Shift.

This starter intentionally contains only a basic client menu. Add and test modules
incrementally so compile errors are easy to identify.
